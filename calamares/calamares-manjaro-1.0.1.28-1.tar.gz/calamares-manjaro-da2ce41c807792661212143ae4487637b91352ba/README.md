# calamares-manjaro
Manjaro specific modules for Calamares
